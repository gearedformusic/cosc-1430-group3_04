/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sudoku_ga3;

import javax.swing.JFrame;

/**
 *
 * @author erpne
 */
public class Sudoku_GA3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //CheckVal sudo;
        //sudo.checkColumn(0, 0);
        
        GUI brainTeaser = new GUI();
        
        brainTeaser.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        brainTeaser.pack();
        brainTeaser.setVisible(true);
    }
    
}
