class Candy: public Food
{
private:
  string sweetness;
  CandyWrapper candyWrap;
public:

  //operator overloading
  bool operator ==( Candy &candy_2);

  void printItem();
  Candy();
  Candy(Candy const&old);
  //accessors
  float GetLenWR(){return candyWrap.GetLen();};
  //mutators
  void setCandyWrap(CandyWrapper obj);
  void setVolume(float vol);
  void setCalories(float cal);
  void setVegetarian(bool veg);
  void setSweetness(string sweet);
  void setColor(string col);
protected:
  float color;


};


Candy::Candy()
:Food::Food(),sweetness("NA"),candyWrap()
{
  //left empty deliberately
  //calls the candyWrap default construcot
  //calls the Food defaults constrctor
}

Candy::Candy(Candy const&old):Food(old)
{
  sweetness = old.sweetness;
  candyWrap = old.candyWrap;
//how about food?
//how to do volume.
}

void Candy::printItem()
{

Food::printItem();
candyWrap.printItem();
cout<<"and a sweetness level of"<<sweetness;

}

void Candy::setCandyWrap(CandyWrapper obj)
{
  //float len = obj.GetLen();
  //candyWrap.SetLen(len);

  //float wid = obj.GetWid();
  //candyWrap.SetWid(wid);

  //string col = obj.GetCol();
  //candyWrap.SetCol(col);
 candyWrap = obj;
}

void Candy::setVolume(float vol)
{
  Food::setVol(vol);
}

void Candy::setCalories(float cal)
{
  Food::setcal(cal);
}

void Candy::setVegetarian(bool veg)
{
  Food::setVeg(veg);
}

void Candy::setSweetness(string sweet)
{
  sweetness = sweet;
}

void Candy::setColor(string col)
{
  candyWrap.SetCol(col);

}

bool Candy::operator ==(Candy &Candy_2)
{
     //if(sweetness == Candy_2.sweetness && candyWrap==Candy_2.candyWrap)
      //return true;
  if(candyWrap.GetLen() == Candy_2.candyWrap.GetLen() && candyWrap.GetCol() == Candy_2.candyWrap.GetCol() && candyWrap.GetWid() == Candy_2.candyWrap.GetWid())
   { if(calories == Candy_2.calories && vegetarian == Candy_2.vegetarian)
     if(Food::getVol() == Candy_2.getVol())
        if(sweetness == Candy_2.sweetness)
        return true;
    }
    else
    return false;






}
