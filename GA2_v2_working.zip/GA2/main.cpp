#include <iostream>
#include <string>
#include "food.h"
#include "candywrapper.h"
#include "candy.h"

using namespace std;

int main(){
Food fd1 = Food(1,200,true);
Food fd2 = Food(fd1);
Candy cd1;
Candy cd2;
CandyWrapper cw1 = CandyWrapper(1,0.5,"red");
CandyWrapper cw2 = CandyWrapper(0.5, 0.25, "blue");
cd1.SetVolume(0.05);
cd1.SetCalories(100);
cd1.SetVegetarian(true);
cd1.SetSweetness(0.7);
cd1.SetColor("pink");
cd1.SetCandyWrap(cw1);
cd2 = cd1;
cd2.SetCandyWrap(cw2);
if (fd1 == fd2)
cout << "we are similar !!" << endl << endl;
else
cout << "we are different !!" << endl << endl;
fd1.printItem();
cout << endl;
fd2.printItem();
cout << endl;
if (cd1 == cd2)
cout << "we are similar !!" << endl << endl;
else
cout << "we are different !!" << endl << endl;
cd1.printItem();
cout << endl;
cd2.printItem();
cout << endl;
system("pause");
return 0;
}
