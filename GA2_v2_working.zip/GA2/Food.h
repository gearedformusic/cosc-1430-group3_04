#ifndef FOOD_H
#define FOOD_H

#include <iostream>
#include <string>
using namespace std;
class Food {
private:
	float volume;

protected:
	int calories;
	bool vegetarian;
public:
	Food();
	Food(float vol, int cal, bool veg);

	//Copy
	Food(const Food &yum);

	//Operator Overload
	bool operator==(Food yum);

	//Mutators
	void SetVolume(float vol) { volume = vol; }
	void SetCalories(int cal) { calories = cal; }
	void SetVegetarian(bool veg) { vegetarian = veg; }

	//Accessors
	float GetVolume(){ return volume; }
	int GetCalories(){ return calories; }
	string GetVegetarian(){
	    if(vegetarian)
            return "a vegetarian";
        else
            return "not a vegetarian";}
	void printItem();
};

Food::Food() {
	volume = 0;
	calories = 0;
	vegetarian = true;
}

Food::Food(float vol, int cal, bool veg) {
	volume = vol;
	calories = cal;
	vegetarian = veg;
}

Food::Food(const Food &yum) {
	volume = yum.volume;
	calories = yum.calories;
	vegetarian = yum.vegetarian;
}

bool Food::operator==(Food yum) {
	return ((yum.volume == volume)
         && (yum.calories == calories)
         && (yum.vegetarian == vegetarian));
}

void Food::printItem() {
	cout << "I am " << GetVegetarian() <<" Food, my volume is " << GetVolume() << " fl. Oz and I have " << GetCalories() << " calories"<< endl;
}

#endif
