#include <iostream>
#include <string>

#include "food.h"
#include "candywrapper.h"
using namespace std;

class Candy : public Food {
private:
    float sweetness;
    CandyWrapper candyWrap;
protected:
    string color;
public:
    Candy();
    Candy(Candy& c);

    //mutators
    void SetColor(string col){color = col;}
    void SetCandyWrap(CandyWrapper wrap){candyWrap = wrap;}
    void SetSweetness(float sweet){sweetness = sweet;}

    //accessors
    string GetColor(){return color;}
    CandyWrapper GetCandyWrap(){return candyWrap;}
    float GetSweetness(){return sweetness;}

    void printItem();

    bool operator==(Candy cane);
};

Candy::Candy(){
    sweetness = 0;
    color = "NA";
    calories = 0;
    SetVolume(0);
    vegetarian = false;
    candyWrap.SetLength(0);
    candyWrap.SetWidth(0);
    candyWrap.SetColor("NA");
    }

Candy::Candy(Candy& c){
    sweetness = c.sweetness;
    color = c.color;
    SetVolume(c.GetVolume());
    calories = c.calories;
    vegetarian = c.vegetarian;
    candyWrap = c.candyWrap;
    }

void Candy::printItem(){
    cout << "I am " << GetVegetarian() << " Candy, my volume is " << GetVolume()
    << " fl.Oz and I have " << GetCalories()<< " calories, my sweetness level is "
    << GetSweetness() << ", my color is " << GetColor() << " and my wrapper has ";
    candyWrap.printItem();

    }

//
bool Candy::operator==(Candy cane){
    return ((cane.sweetness == sweetness)
         && (cane.color == color)
         && (cane.candyWrap.GetColor() == candyWrap.GetColor())
         && (cane.candyWrap.GetLength() == candyWrap.GetLength())
         && (cane.candyWrap.GetWidth() == candyWrap.GetWidth())
         && (cane.GetVolume() == GetVolume())
         && (cane.calories == calories)
         && (cane.vegetarian == vegetarian));
}
